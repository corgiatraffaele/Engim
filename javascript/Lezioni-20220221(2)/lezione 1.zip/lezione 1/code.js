console.log("hello world!");

console.log('TIPI DI DATO');

// sdfjbksbdfkjbskjfbkjbsfkjb


/*
dfsdgsdg
sdgsdggds
sgsgsdgsdg
sdgsgsg
sdgsdgsdgsdgsdg
sgsgdsdsdgsgsdgsdfgdsgsd
dgdsfgdgsfdgsfdfgs
dfsgsdg
*/
//


// sto loggando il tipo di unn stringa
console.log( typeof("ciao sono una stringa") )
// "string"

console.log( typeof(true) )
// "boolean"

console.log( typeof(42) )
// "number"



console.log('OPERATORI')
console.log(3%3)






