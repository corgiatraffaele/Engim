// loggare tutti i numeri pari tra 2 numeri presenti nelle
// variabili start ed end compresi
// usare un ciclo while per risovere questo esercizio
// diamo per scontato che start sarà sempre minore di end

let start = 10
let end = 21

while(start<=end){
    if(start%2 == 0){ console.log(start) }
    start++
}
