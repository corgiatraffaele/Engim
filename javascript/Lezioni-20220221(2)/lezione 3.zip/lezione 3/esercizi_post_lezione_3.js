// Usando un ciclo for loggare in console i quadrato di ogni numero
// per ottenere la dimensione dell'array usasare la prorpieta length

let numeri = [2, 4, 54, 66, 78, 99, 102]

