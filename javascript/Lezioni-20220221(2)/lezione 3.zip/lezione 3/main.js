

// Esempio while loop
let index = 0
while(index<=10){
    console.log(index)
    index=index+1
}

// Esempio for loop
for(let index=0; index<=10; index++){
    console.log(index)
}
